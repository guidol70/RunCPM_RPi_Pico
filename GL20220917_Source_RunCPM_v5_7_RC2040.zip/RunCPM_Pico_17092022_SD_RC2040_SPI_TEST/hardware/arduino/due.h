#ifndef DUE_H
#define DUE_H

SdFat SD;
#define SDMHZ 40
#define SDINIT 4, SD_SCK_MHZ(SDMHZ)
#define LED 13
#define LEDinv 0
#define BOARD "Arduino Due"
#define board_due
#define board_analog_io
#define board_digital_io


#endif