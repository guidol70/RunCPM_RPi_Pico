// ==================================================================================

  void   _neop_none(void) {
		// OFF/NONE
		pixels.setPixelColor(0, pixels.Color(0, 0, 0));
		pixels.show();
}

  void   _neop_red(void) {
		// RED
		pixels.setPixelColor(0, pixels.Color(20, 0, 0));
		pixels.show();
}

  void   _neop_green(void) {
		// GREEN
		pixels.setPixelColor(0, pixels.Color(0, 20, 0));
		pixels.show();
}

  void   _neop_blue(void) {
		// BLUE
		pixels.setPixelColor(0, pixels.Color(0, 0, 20));
		pixels.show();
}

  void   _neop_yellow(void) {
    // BLUE
    pixels.setPixelColor(0, pixels.Color(20, 20, 10));
    pixels.show();
}

// ==================================================================================
