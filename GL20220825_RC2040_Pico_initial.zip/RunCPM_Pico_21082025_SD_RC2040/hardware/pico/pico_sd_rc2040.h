SdFat SD;

// #define SS 5 //Bug fix, you have to define this because later it is used by SD.init. This was missed out on the master branch.
// #define MISO 4
// #define MOSI 3
// #define SCK 2

// ------------------------------------------------
// SPIINIT !!ONLY!!  used on ESP32
// #define SPIINIT Clock, MISO, MOSI, Card-Select
// ------------------------------------------------
#define SPIINIT 2,4,3,SS 
#define SPIINIT_TXT "2,4,3,5"


// MicroSD Pin Definition for RC2040 board
// Pin 6 - GPIO 4 MISO
// Pin 7 - GPIO 5 Chip/Card-Select (CS / SS)
// Pin 4 - GPIO 2 Clock (SCK)
// Pin 5 - GPIO 3 MOSI

// Normal RPi Pico 
// MISO - Pin 21 - GPIO 16
// MOSI - Pin 25 - GPIO 19
// CS   - Pin 22 - GPIO 17
// SCK  - Pin 24 - GPIO 18
 
// normal is 12Mhz because of https://www.pschatzmann.ch/home/2021/03/14/rasperry-pico-with-the-sdfat-library/
#define SDMHZ 19
#define SDMHZ_TXT "19" 
#define SDINIT SS, SD_SCK_MHZ(SDMHZ)

#define ENABLE_DEDICATED_SPI 1

// GP25 green onboard LED
#define LED 25  // GPIO25
#define LEDinv 0
#define board_due
#define board_analog_io
#define board_digital_io

// #endif