// =========================================================================================
// Define SdFat as alias for SD
// =========================================================================================
SdFat SD;

// =========================================================================================
// Define Board-Data
// GPIO 25 oboard green   LED
// GPIO  6 RC2040 PCB red LED
// =========================================================================================
#define LED 6     // GPIO  6 RC2040 PCB red LED
// #define LED 25     // GPIO  6 RC2040 PCB red LED
#define RLED 6     // GPIO  6 RC2040 PCB red LED
#define GLED 25    // GPIO 25 oboard green   LED
#define LEDinv 0
#define board_pico
#define board_analog_io
#define board_digital_io
#define BOARD "RC2040 Pico"

// =========================================================================================
// Pin Documentation
// =========================================================================================
// MicroSD Pin Definition for RC2040 board
// GPIO 4 MISO
// GPIO 5 Chip/Card-Select (CS / SS)
// GPIO 2 Clock (SCK)
// GPIO 3 MOSI
